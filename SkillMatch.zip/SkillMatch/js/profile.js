import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";

import { getFirestore,
         doc, 
         setDoc, 
         getDoc } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-firestore.js";

import { getAuth, 
         onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-auth.js";



const firebaseConfig = {
    apiKey: "AIzaSyA_c4U7uOv6cOcotBooD-zBniMEHzyYSmA",
    authDomain: "skillmatch-24689.firebaseapp.com",
    projectId: "skillmatch-24689",
    storageBucket: "skillmatch-24689.firebaseapp.com",
    messagingSenderId: "168430588610",
    appId: "1:168430588610:web:d99323c5649d64ab78215b"
};



const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);



const CLOUDINARY_URL = "https://api.cloudinary.com/v1_1/dihfkfstr/image/upload"; 
const CLOUDINARY_PRESET = "skillMatch"; 



const profilePhoto = document.getElementById("profile-photo");
const profilePhotoInput = document.getElementById("profile-photo-input");
const uploadPhotoBtn = document.getElementById("upload-photo-btn");
const saveProfileBtn = document.getElementById("save-profile-btn");
const availabilityToggle = document.getElementById("availability-toggle");

let currentUserId = null;



async function loadUserProfile(userId) {
    try {
            loadingIndicator.style.display = "block";

        const userDoc = await getDoc(doc(db, "profile", userId));

        if (userDoc.exists()) {
            const data = userDoc.data();
            
            profilePhoto.src = data.profilePhoto || "default-avatar.png";
            document.getElementById("profile-name").textContent = data.name || "John Doe";
            document.getElementById("profile-title").value = data.title || "";
            document.getElementById("about-me").value = data.aboutMe || "";
            document.getElementById("skills").value = data.skills?.join(", ") || "";
            document.getElementById("project-interests").value = data.projectInterests || "";
            document.getElementById("contact-email").value = data.email || "";
            document.getElementById("contact-phone").value = data.phone || "";
            availabilityToggle.checked = data.isAvailable || false;
        }
    } catch (error) {
        console.error("Error loading profile:", error);
        alert("Error loading profile. Please try again.");
    } finally {
        loadingIndicator.style.display = "none";
    }
}



async function saveUserProfile() {
    if (!currentUserId) {
        alert("User not authenticated. Please log in.");
        return;
    }
    const profileData = {
        name: document.getElementById("profile-name").textContent,
        title: document.getElementById("profile-title").value,
        aboutMe: document.getElementById("about-me").value,
        skills: document.getElementById("skills").value.split(",").map(skill => skill.trim()),
        projectInterests: document.getElementById("project-interests").value,
        email: document.getElementById("contact-email").value,
        phone: document.getElementById("contact-phone").value,
        isAvailable: availabilityToggle.checked,
    };
    if (!validateProfileData(profileData)) return;

    saveProfileBtn.disabled = true;
    saveProfileBtn.textContent = "Saving...";

    try {
        await setDoc(doc(db, "profile", currentUserId), profileData, { merge: true });
    } catch (error) {
        console.error("Error saving profile:", error);
        alert("Error saving profile. Please try again.");
    } finally {
        saveProfileBtn.disabled = false;
        saveProfileBtn.textContent = "Save Profile";
    }
}



const loadingIndicator = document.getElementById("loading-indicator");
uploadPhotoBtn.addEventListener("click", () => profilePhotoInput.click());

profilePhotoInput.addEventListener("change", async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);
    formData.append("upload_preset", CLOUDINARY_PRESET);

    loadingIndicator.style.display = "block";
    uploadPhotoBtn.disabled = true;

    try {
        const response = await fetch(CLOUDINARY_URL, { method: "POST", body: formData });
        const data = await response.json();

        if (data.secure_url) {
            profilePhoto.src = data.secure_url;

            if (currentUserId) {
                await setDoc(doc(db, "profile", currentUserId), { profilePhoto: data.secure_url }, { merge: true });
            } else {
                alert("User not authenticated. Please log in.");
            }
        } else {
            alert("Error uploading photo. Please try again.");
        }
    } catch (error) {
        console.error("Upload failed:", error);
        alert("Error uploading photo. Please try again.");
    } finally {
        loadingIndicator.style.display = "none";
        uploadPhotoBtn.disabled = false;
    }
});



onAuthStateChanged(auth, (user) => {
    if (user) {
        currentUserId = user.uid;
        loadUserProfile(currentUserId);
    } else {
        alert("User not logged in. Please log in to access your profile.");
        currentUserId = null;
    }
});


function validateProfileData(data) {
    if (!data.name.trim()) {
        alert("Name is required.");
        return false;
    }
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
        alert("Please enter a valid email address.");
        return false;
    }
    if (!data.projectInterests.trim()) {
        alert("Project Interests are required.");
        return false;
    }
    if (!data.skills || data.skills.length === 0 || !data.skills.some(skill => skill.trim())) {
        alert("Please enter at least one skill.");
        return false;
    }
    return true;
}


saveProfileBtn.addEventListener("click", saveUserProfile);
